# Golddigger Worker Docker repo
This repository contains the Dockerfile and other configuration files required for building Golddigger worker docker image. This image is intended to run on Amazon ECS service

The Golddigger worker is website Scrapping tool based on Python 3. It uses `Celery` which is a asynchronous task queue/job queue based on distributed message passing. 

OpenVPN client is also installed in the image for IP masking. The VPN server to which the client connects is randomly selected using the script inside the docker.

Supervisord is used to monitor and manage Celery and OpenVPN client processes inside the Docker Container.

Golddigger worker code is not included in the image. It will be deployed to EC2 instances via AWS CodeDeploy service.

If you need to update/remove python packages used by Golddigger Worker application, edit the file `requirements.txt` and build the image.

### Volumes
 - /home/ubuntu/golddigger/ (Mount to the code directory of the host machine. Handled by AWS Code deploy service)
 
After building the image, upload the image to the Amazon Docker repo `116803286952.dkr.ecr.us-east-1.amazonaws.com/golddigger-worker`
`

## Building the image 

1. Extract the contents to a directory. To start the build process:
    ```
    docker build -t golddigger-scrapper:<version> .
    ```
2. Login to Amazon Docker repo. You can get the login command via running following script.
    ```
    aws ecr get-login --no-include-email --region us-east-1
    ```
3. Tag the docker image
    ```
    docker tag (ImageID of golddocker-scrapper:<version>) 116803286952.dkr.ecr.us-east-1.amazonaws.com/golddigger-worker:<version>
    ```
4. Push the tagged image to Amazon Docker repository
    ```
    docker push 116803286952.dkr.ecr.us-east-1.amazonaws.com/golddigger-worker:<version>
    ```

## ECS Task definition
The json file required to create task definition in AWS ECS service is uploaded to [ecs_task](https://github.com/Legalinc/golddigger-worker-docker/tree/master/ecs_task) folder.
