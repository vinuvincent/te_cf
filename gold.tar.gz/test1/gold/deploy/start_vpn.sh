#!/bin/sh
VPN_CONFIG_DIR="/home/ubuntu/vpn/vpn_config/"
cd ${VPN_CONFIG_DIR}
VPN_CONFIG=`ls | shuf -n 1`
echo "${VPN_CONFIG}" > /home/ubuntu/vpn/vpn_server.txt
openvpn --config ${VPN_CONFIG}