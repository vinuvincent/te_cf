import requests
print(requests.get("http://icanhazip.com/").text)