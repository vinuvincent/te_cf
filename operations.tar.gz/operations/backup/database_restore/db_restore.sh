#!/bin/bash
backup_date=`date -d"-1 days" '+%Y-%m-%d'`
AWS="/usr/local/bin/aws --profile backupuser_s3"
DB_LIST=(acs cms comms incfile mycorp OrderManager legalinc)
BACKUP_DIR="sql_dump"
VPC=$1

#Check for Command line Arguments
if [ "$#" -ne 1 ] ; then
    echo "Arguments not sufficient! << Usage: $0 development | uat >>"
    exit 1
fi

#Selecting Restore list based on VPC
echo "Environment: $VPC"
if [[ $VPC == "development" ]]; then
  RESTORE_LIST=(acs cms comms incfile mycorp OrderManager legalinc_development)
  DB_HOST="dev-db.cgdgt1kn7bju.us-east-1.rds.amazonaws.com"
elif [[ $VPC == "uat" ]] ; then
  RESTORE_LIST=(acs cms comms incfile mycorp OrderManager legalinc_uat)
  DB_HOST="uat-db.cgdgt1kn7bju.us-east-1.rds.amazonaws.com"
fi

#Check whether MySQL Client is installed
which mysql 2>&1 > /dev/null
if [ "$?" -ne 0 ]
  then 
   echo "ERROR: MySQL client not found on the host: `hostname`"
   exit 1
else
  echo "MySQL client found on the host: `hostname`"
fi

#Check whether gunzip is installed
which gunzip 2>&1 > /dev/null
if [ "$?" -ne 0 ]
  then 
   echo "ERROR: gunzip not found on the host: `hostname`"
   exit 1
else
  echo "gunzip found on the host: `hostname`"
fi

#Check for database connectivity
mysql -h $DB_HOST -e "SELECT VERSION();" 2>&1
if [ "$?" -ne 0 ]
  then
  echo "ERROR: Unable to connect to MySQL server:'$DB_HOST'. Check my.cnf file"
  exit 1
else
  echo "Able to connect to MySQL server:'$DB_HOST'"
fi

mkdir -p ${BACKUP_DIR}
if [ "$?" -ne 0 ]
  then
	echo "ERROR: Cannot create backup directory $BACKUP_DIR. Go and fix it!"
    exit 1
fi
printf %"s\n" 

echo "-----------Checking for Recent backups in S3---------"
echo "Backup date: ${backup_date}"
printf %"s\n"
for i in "${DB_LIST[@]}"
do
  echo "Checking Database: $i"
  $AWS s3 ls s3://legalinc-db-backups/RDS_Backup/$i-${backup_date}.sql.gz
  if [ "$?" -ne 0 ];then
    echo "ERROR: Recent backups not available for Database $i. Contact DevOps Team"
    exit 1
  fi
printf %"s\n"
done
echo "-------SUCCESS:Recent Backups available in S3----------"
printf %"s\n" 

echo "-------------Downloading backup from S3------------"
for i in "${DB_LIST[@]}"
do  
	printf %"s\n" 
	echo "Downloading backup of $i. Please wait..."
	$AWS s3 cp --no-progress s3://legalinc-db-backups/RDS_Backup/$i-${backup_date}.sql.gz ${BACKUP_DIR}/$i-${backup_date}.sql.gz
	if [ "$?" -ne 0 ]; then 
   		echo "ERROR: Failed to download sql file $i-${backup_date}.sql.gz from S3"
  fi
  echo "Decompressing backup file"
  gunzip -v -f -d sql_dump/$i-${backup_date}.sql.gz
done
printf %"s\n" 
echo "-------SUCCESS: Backups Downloaded from S3-----------"
printf %"s\n" 

cd ${BACKUP_DIR}
#Updating MySQL user in dump files
if [ -f legalinc-${backup_date}.sql ]; then
	printf %"s\n" 
	echo "Updating definers in dump file legalinc-${backup_date}.sql"
	sed -i 's?DEFINER=`forge`@`%`?DEFINER=`masteruser`@`%`?g' legalinc-${backup_date}.sql
  #Renaming backup file to match the Restore DB list
  mv -v legalinc-${backup_date}.sql legalinc_${VPC}-${backup_date}.sql
fi

if [ -f OrderManager-${backup_date}.sql ]; then
	printf %"s\n" 
	echo "Updating definers in dump file OrderManager-${backup_date}.sql"
    sed -i 's?DEFINER=`forge`@`%`?DEFINER=`masteruser`@`%`?g' OrderManager-${backup_date}.sql
fi
printf %"s\n" 

echo "-------------Restoration begins-------------"
for i in "${RESTORE_LIST[@]}"
do
	if [ -f $i-${backup_date}.sql ]; then
	  printf %"s\n"
	  echo "Working on Database: $i"
	  #echo "Restoring database $i from $i-${backup_date}.sql. Please wait..."
	  mysql -h $DB_HOST $i < $i-${backup_date}.sql
	  if [ "$?" -ne 0 ]; then 
   		echo "ERROR: Failed to restore dump file $i-${backup_date}.sql.Exiting...."
   		exit 1
      fi
      echo "SUCCESS: Restoration of Database $i Completed"
	fi
done
echo "-------------All Databases Restorated Successfully -------------"

echo "Removing downloaded files"
if [ -d "../$BACKUP_DIR" ]; then
  rm -rfv "../$BACKUP_DIR"
fi