#!/bin/bash
#To backup SQL dump backup of all databases in RDS
#Configurable variables
DB_HOST=ordermanager-production.cgdgt1kn7bju.us-east-1.rds.amazonaws.com
DB_USER=forge
DB_PORT=3306
BACKUP_DIR=sql_dump
#DB_LIST=(acs cms incfile mycorp)
#Pass DB list as cmd args
DB_LIST=("$@") 
backup_date=`date '+%Y-%m-%d'`

AWS="/usr/local/bin/aws --profile backupuser_s3"
#Provide trailing slash ("/")
S3_BASE_PATH="s3://legalinc-db-backups/RDS_Backup/"
#RETENTION in days
RETENTION="7"

#---------------------Database backup Section-----------------------
if [ ${#DB_LIST[@]} -eq 0 ] ; then
    echo "Arguments not sufficient! << Usage: $0 Database_list >>"
    exit 1
fi

#Check whether MySQL Client is installed
which mysqldump 2>&1 > /dev/null
if [ "$?" -ne 0 ]
then 
	echo "ERROR: MySQL Dump utility not found on the host: `hostname`"
	exit 1
else
	echo "Mysqldump Binary found on the host: `hostname`"
fi

#Check whether GZIP is installed
which gzip 2>&1 > /dev/null
if [ "$?" -ne 0 ]
then 
	echo "ERROR: gzip not found on the host: `hostname`"
	exit 1
else
	echo "gzip found on the host: `hostname`"
fi

RDS_RUN="mysql -s -h $DB_HOST -u $DB_USER -P $DB_PORT"
RDS_DUMP="mysqldump -h $DB_HOST -u $DB_USER -P $DB_PORT"

#Check for database connectivity
$RDS_RUN -e "SELECT VERSION();" 2>&1
if [ "$?" -ne 0 ]
then
	echo "ERROR: Unable to connect to MySQL server:'$DB_HOST'"
	exit 1
else
	echo "Able to connect to MySQL server:'$DB_HOST'"
fi

echo "Making backup directory '$BACKUP_DIR', if not exists" 
mkdir -p $BACKUP_DIR
if [ "$?" -ne 0 ]
then
	echo "ERROR: Cannot create backup directory $BACKUP_DIR. Go and fix it!"
	exit 1
fi
printf %"s\n" 

echo "Database Array: ${DB_LIST[@]}"
for i in "${DB_LIST[@]}"
do
	#access each element as $i. . .
	echo "Working on Database: $i"
	echo "=============================="
	$RDS_DUMP $i | gzip > "${BACKUP_DIR}/$i-${backup_date}.sql.gz"
	if [ "$?" -ne 0 ]
		then
		echo "ERROR: Unable to create Backup of $i"
		exit 1
	else 
		echo "SQL dump created for Database: $i"
		ls -lh ${BACKUP_DIR}/$i-${backup_date}.sql.gz
		printf %"s\n" 
		
		#Upload to S3
		echo "Uploading Backup to S3. Please wait..."
		$AWS s3 cp --no-progress ${BACKUP_DIR}/$i-${backup_date}.sql.gz ${S3_BASE_PATH}
				
		# Removing local copy
		if [ "$?" -ne 0 ]
		then
			echo "ERROR: Cannot upload backup to S3!!!"
			exit 1
		else
			printf %"s\n"
			echo "Backup Uploaded to S3. Removing local Copy"
			rm -fv ${BACKUP_DIR}/$i-${backup_date}.sql.gz
		fi
	fi
	printf %"s\n \n"
done

# ----------------------S3 Retention Section----------------------------
#Delete Function
Delete_Backup()
{
RETENTION=$1
S3_BASE_PATH=$2
	OlderThan=`date -d"-${RETENTION} days" '+%s'`
	echo "OlderThan Date: $(date -d"-${RETENTION} days" +'%Y-%m-%d %H:%M:%S')"
	#echo "OlderThan Date EPOCH: $OlderThan"
	echo "-------------Following Backup Files will be Deleted-----------------"
	printf "\n"
	while read line 
	do 
		CREATED_DATE=`echo $line| awk '{print $1" "$2 }'`
		CREATED_DATE_EPOCH=`date -d"${CREATED_DATE}" +%s`
		if [[ $CREATED_DATE_EPOCH < $OlderThan ]]
		then
			FileName=`echo $line| awk '{print $4}'`
			if [[ $FileName != "" ]]
			then
				echo "FileName: $S3_BASE_PATH$FileName"
				echo "CREATED_DATE: $CREATED_DATE"
				#echo "CREATED_DATE_EPOCH: $CREATED_DATE_EPOCH"	
				echo "Removing Backup from S3"
				$AWS s3 rm ${S3_BASE_PATH}${FileName}
				#$AWS s3 ls "$S3_BASE_PATH""$FileName"
			fi
		fi
		printf "\n" 
	done < db_list.txt
}

echo "Gathering list of backup files in S3 path: $S3_BASE_PATH"
$AWS s3 ls "$S3_BASE_PATH" > db_list.txt
if [[ ! -s db_list.txt ]]
then
	echo "Failed to create Backup list: Exiting..."
	exit 1
fi
#cat db_list.txt

#If backups are present, count will greater than 2
Backup_Count=`wc -l db_list.txt | awk '{print $1}'`

if [[ "$Backup_Count" -ge 2 ]]
then
	echo "Invoking Delete Function"
	Delete_Backup $RETENTION $S3_BASE_PATH
fi
