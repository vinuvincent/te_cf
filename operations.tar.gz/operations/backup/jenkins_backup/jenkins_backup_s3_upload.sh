#!/bin/bash
#####
##Jenkins jobs are backuped by ThinBackup plugin as zip file. 
##This script copies zip files to S3 and handles s3 retenton
#####
#Configurable variables
BACKUP_DIR="/opt/backups"
#Provide trailing slash ("/")
S3_BASE_PATH="s3://legalinc-db-backups/Jenkins_backup/"
AWS="/usr/local/bin/aws --profile backupuser_s3"
backup_date=`date '+%Y-%m-%d'`
#RETENTION in days
RETENTION="14"

#---------------------S3 backup upload Section-----------------------

for i in `find $BACKUP_DIR -type f -name "*.zip"`
do
	$AWS s3 cp --no-progress $i ${S3_BASE_PATH}
	if [ "$?" -ne 0 ]; then
		echo "ERROR: Cannot upload backup to S3!!!"
		exit 1
	fi
done

# ----------------------S3 Retention Section----------------------------
#Delete Function
Delete_Backup()
{
RETENTION=$1
S3_BASE_PATH=$2
OlderThan=`date -d"-${RETENTION} days" '+%s'`
echo "OlderThan Date: $(date -d"-${RETENTION} days" +'%Y-%m-%d %H:%M:%S')"
#echo "OlderThan Date EPOCH: $OlderThan"
echo "-------------Following Backup Files will be Deleted-----------------"
printf "\n"
while read line 
do 
	CREATED_DATE=`echo $line| awk '{print $1" "$2 }'`
	CREATED_DATE_EPOCH=`date -d"${CREATED_DATE}" +%s`
	if [[ $CREATED_DATE_EPOCH < $OlderThan ]];then
		FileName=`echo $line| awk '{print $4}'`
		if [[ $FileName != "" ]]
		then
			echo "FileName: $S3_BASE_PATH$FileName"
			echo "CREATED_DATE: $CREATED_DATE"
			#echo "CREATED_DATE_EPOCH: $CREATED_DATE_EPOCH"	
			echo "Removing Backup from S3"
			$AWS s3 rm ${S3_BASE_PATH}${FileName}
		fi
	fi
	printf "\n" 
done < db_list.txt
}

echo "Gathering list of backup files in S3 path: $S3_BASE_PATH"
$AWS s3 ls "$S3_BASE_PATH" > db_list.txt
if [[ ! -s db_list.txt ]]
then
	echo "Failed to create Backup list: Exiting..."
	exit 1
fi
#cat db_list.txt

#If backups are present, count will greater than 2
Backup_Count=`wc -l db_list.txt | awk '{print $1}'`

if [[ "$Backup_Count" -ge 2 ]]
then
	echo "Invoking Delete Function"
	Delete_Backup $RETENTION $S3_BASE_PATH
fi