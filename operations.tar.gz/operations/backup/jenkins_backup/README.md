# Jenkins Job Backup

ThinBackup plugin takes daily backup of Jenkins jobs as zip file and store them in the location `/opt/backups`. This script copies zip files to S3 path specified. It also handles the retention of backups stored in S3 path. The retention of local zip files are handled by ThinBackup plugin itself. 

` Usage: ./jenkins_backup_s3_upload.sh `

## Prerequisites

1. An IAM  user `backupuser_s3` with following policy is needed for this script. This user should be configured on the server where this script is executed.
```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::legalinc-db-backups"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::legalinc-db-backups/*"
            ]
        }
    ]
}
```

2. Install ThinBackup jenkins plugin and schedule daily FULL backup option.


