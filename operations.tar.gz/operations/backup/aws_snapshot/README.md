# aws_snapshot
Script to automate snapshot creation of aws instance volumes 

```
Usage: ./aws_backup.sh <<AWS_PROFILE>>
```
- Monthly/Weekly/Daily backups
- Tag the instances with "Backup:true" for enabling backups

Create IAM backup user with following policy

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "AWSSnapshot",
            "Effect": "Allow",
            "Action": [
                "ec2:CreateSnapshot",
                "ec2:DeleteSnapshot",
                "ec2:DescribeSnapshotAttribute",
                "ec2:DescribeSnapshots",
                "ec2:DescribeTags",
                "ec2:DescribeVolumeAttribute",
                "ec2:DescribeVolumeStatus",
                "ec2:DescribeVolumes",
                "ec2:DescribeInstances",
                "ec2:ModifySnapshotAttribute",
                "ec2:ResetSnapshotAttribute",
                "ec2:CreateTags",
                "ec2:DeleteTags",
                "ec2:DescribeTags"
            ],
            "Resource": [
                "*"
            ]
        }
    ]
}
```