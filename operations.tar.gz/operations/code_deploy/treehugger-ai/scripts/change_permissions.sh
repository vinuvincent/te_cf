#!/bin/bash
APP_PATH="/home/ubuntu/treehugger-ai"
VENV_PATH="/home/ubuntu/env/treehugger-ai"
#Change permission of document root and efs mount points
echo "Reset permission of document root and efs mount points"
sudo chown -R ubuntu:ubuntu $APP_PATH
sudo chown -R ubuntu:ubuntu /home/ubuntu/media
if [ $? -ne 0 ]
then
	echo "Faced issue while resetting perms of some files in NFS. Files may be processed by another worker."
else
	echo "Successfully reset permission of NFS files"
fi

#Installing Python modules
# export LC_ALL="en_US.UTF-8"
# export LC_CTYPE="en_US.UTF-8"
# source $VENV_PATH/bin/activate
# echo "Installing Python modules"
# pip install -r ${APP_PATH}/LegalInc_AI/requirements.txt
# if [ $? -ne 0 ]
# then
# 	echo "Failed to install python packages."
# 	exit 1
# else
# 	echo "Python packages installed"
# 	deactivate
# fi