# AWS Code Deploy Configuration

AWS CodeDeploy is a service that automates software deployments to a variety of compute services including Amazon EC2, AWS Lambda, and instances running on-premises. AWS CodeDeploy makes it easier for you to rapidly release new features, helps you avoid downtime during application deployment, and handles the complexity of updating your applications.

Codedeploy decides how to deploy the code based on the `appspec.yml` file. This file and the associated directories should be zipped along with the codebase.