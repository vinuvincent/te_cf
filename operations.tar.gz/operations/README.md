# Operations Repo

This repository contains the backup scripts and other operations related scripts