#!/bin/bash
#Restarting Celery server
systemctl enable celery.service
systemctl restart celery.service
if [ $? -ne 0 ]
then
	echo "Failed to start Celery service."
	exit 1
else
	echo "Celery Started"
fi
#Restarting amazon-cloudwatch-agent.service service
systemctl restart amazon-cloudwatch-agent.service
if [ $? -ne 0 ]
then
	echo "Failed to start amazon-cloudwatch-agent service."
	exit 1
else
	echo "amazon-cloudwatch-agent service Started"
fi