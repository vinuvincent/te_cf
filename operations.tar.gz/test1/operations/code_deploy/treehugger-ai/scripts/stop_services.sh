#!/bin/bash
#Stopping Celery
echo "Stopping Celery service"
systemctl stop celery.service
if [ $? -ne 0 ]
then
	echo "Failed to stop Celery service."
	exit 1
else
	echo "Celery Stopped"
fi