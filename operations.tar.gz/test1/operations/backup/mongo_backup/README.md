# MongoDB Database Backup

This script takes backup of databases in production MongoDB Atlas servers and uploads them to S3 location `s3://legalinc-db-backups/Mongo_Backup/`. It also handles the retention of backups stored in S3 path

` Usage: mongo_backup.sh MONGO_USER MONGO_USER_PASS`

## Prerequisites

1. An IAM  user `backupuser_s3` with following policy is needed for this script. This user should be configured on the server where this script is executed.
s
```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::legalinc-db-backups"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::legalinc-db-backups/*"
            ]
        }
    ]
}
```

2. Install Mongodump version 3.4.x in the server where the script is executed.


