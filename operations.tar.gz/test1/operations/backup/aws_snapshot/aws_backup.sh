#!/bin/bash
# Purpose : Automate the backup by using snapshots
# Version : 1.1
###################

if [ "$#" -ne 1 ] ; then
    echo "Arguments not sufficient! << Usage: $0 AWS_PROFILE >>"
    exit 1
fi

# Configurable settings.
# RETENTION
# Retention can be 0 , 1 or 2 . 0 means no backup . 1 means daily backup will take place. 2 means backup will happen only on alternate days.
RETENTION_DAY='1'

# Retention can be 0 , 1 or 2 . 0 means no backup . 1 means weekly backup will take place. 2 means backup will happen only on alternate weeks.
RETENTION_WEEK='0'
#On which day of week weekly backup must run. Values 1 to 7 where 1 is Monday
BACK_WEEK_DAY='7' 

#Monthly backup enabled or not "1 means yes 0 no" 
BKP_MONTHLY='0' 
#On which day of Month monthly backup must run. Values 1 to 31
BACK_MON_DAY='01' 

# AWS cli setting
AWS="/usr/local/bin/aws"
PROFILE="$1"
#VAR's
DATE=`/bin/date '+%Y%d%m'`
echo "Date : $DATE"
WEEKDAY=`/bin/date '+%A'`
echo "Weekday : $WEEKDAY"
#WEEKNO=`echo $((($(/bin/date +%d)-1)/7+1))`
WEEKNO=`/bin/date '+%V'`
echo "Week No : $WEEKNO"
MONNO=`/bin/date '+%m'`
echo "Mon No : $MONNO"
DAYNO_WEEK=`date '+%u'`
echo "Day No of Week : $DAYNO_WEEK"
DAYNO_MONTH=`date '+%d'`
echo "Day no of Mon : $DAYNO_MONTH"

#Purge backup
purge_snap(){
	BACKUP=$1
	echo "Backup description : $BACKUP"
    oldifs="$IFS";IFS=$'\n'
    OLD_BACKUPS=($($AWS --profile $PROFILE ec2 describe-snapshots --filter "Name=volume-id,Values=$volume" --output text --query "Snapshots[*].[Description, SnapshotId]"| grep $BACKUP ))
    IFS=$oldifs
        for old_backup in "${OLD_BACKUPS[@]}"; do
            old_backup_id=`echo $old_backup | awk '{print $NF}'`
            old_backup_des=`echo $old_backup |awk 'NF{NF-=1};1'`
                if [[ $old_backup_des =~ $BACKUP-[0-9]{8}  ]] ; then
                    echo "Deleting old backup: $old_backup_des  => $old_backup_id"
                    $AWS --profile $PROFILE ec2 delete-snapshot --snapshot-id $old_backup_id
                    if [ "$?" -ne 0 ]
	  				  then 
						echo  "ERROR!!: Unable to Delete Snapshot"
	  				    exit 1
					fi
                fi
        done
}

create_snap(){
	VOLUME=$1
	BACKUP=$2
	INSTANCE_NAME=$3
	SNAP_ID=`$AWS --profile $PROFILE ec2 create-snapshot  --volume-id $VOLUME --description "${BACKUP}-${DATE}" --output text  --query SnapshotId`
	echo "Snap created with id : $SNAP_ID"
    $AWS --profile $PROFILE ec2 create-tags --resources $SNAP_ID --tags Key=Name,Value="${INSTANCE_NAME}-automated-$4-snap-${DATE}"
    if [ "$?" -ne 0 ]
	  then 
		echo  "ERROR!!: Unable to Create Snapshot"
	  exit 1
	fi
}

snap_call() {
for instance in `cat /tmp/.backup`; do
#Get Instance and volumes 
	INSTANCE_NAME=`$AWS --profile $PROFILE ec2 describe-instances --instance-ids=$instance --output text | grep -E "TAGS.*Name" | awk '{print $NF}'`
	echo "Instance : $INSTANCE_NAME"
	VOLUME=`$AWS --profile $PROFILE ec2 describe-instances --instance-ids=$instance --output text --query 'Reservations[].Instances[].BlockDeviceMappings[].Ebs[].VolumeId'`
	for volume in $VOLUME; do
		echo "Volume : $volume"
		BACKUP="${INSTANCE_NAME}-${volume}-$1"
		purge_snap $BACKUP
		create_snap $volume $BACKUP $INSTANCE_NAME $1
		echo "-----------------"
	done
done
}


## Main
# Get instance that need backup
$AWS --profile $PROFILE ec2 describe-instances --filters "Name=tag:Backup,Values=true" --output text --query 'Reservations[].Instances[].[InstanceId]'  > /tmp/.backup
if [ "$?" -ne 0 ]
	then 
		echo  "ERROR!!: Verify the provided AWS access credentials"
	exit 1
fi

# Run monthly backups
if [[ $BACK_MON_DAY = $DAYNO_MONTH ]]; then
        if [[ $BKP_MONTHLY = 0 ]];then
                echo "Sorry no Monthly backup set"
        elif [[ $BKP_MONTHLY = 1 ]]; then
		echo "Running Monthly backup for mon : $MONNO"
                snap_call "MON${MONNO}" 
        else
                echo "Not a valid monthly option"
        fi
fi

# Run Weekly backups
if [[ $BACK_WEEK_DAY = $DAYNO_WEEK ]]; then
	if [[ $RETENTION_WEEK = 0 ]]; then
		echo "Sorry no weekly backup set"
	elif [[ $RETENTION_WEEK = 1 ]]; then
		echo "Running Weekly backup for week : $WEEKNO"
		snap_call "WEEK${WEEKNO}"
	elif [[ $RETENTION_WEEK = 2  &&  $(( $WEEKNO % 2 )) != "0"  ]] ; then
		echo "Running Weekly backup for week : $WEEKNO"
		snap_call "WEEK${WEEKNO}"
	else
		echo "Not a valid weekly option"
	fi
fi

# Run daily backups
if [[ $RETENTION_DAY = 0 ]];then  
	echo "Sorry no backup"
elif [[ $RETENTION_DAY = 1 ]]; then
	snap_call $WEEKDAY
elif [[ $RETENTION_DAY = 2 &&  $(( $DAYNO_WEEK % 2 )) != "0"  ]] ; then
	snap_call $WEEKDAY
else
	echo "Not a valid daily option"
fi
