# RDS Restore Scripts

This folder contains the restore scripts which restores production databases in Development and Uat RDS servers using the latest production backups available in S3.
```
Usage: db_restore.sh <VPC> (development|uat)
```
##Prerequisites:- 
* Script can be run from any server under development/QA VPC 
* aws cli and my.cnf file should be configured in the server 
* gunzip and mysql binaries should be installed