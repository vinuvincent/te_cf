# RDS Database Backup

This script takes backup of databases in production MySQL RDS server `ordermanager-production.cgdgt1kn7bju.us-east-1.rds.amazonaws.com` and uploads them to S3 location `s3://legalinc-db-backups/RDS_Backup/`. It also handles the retention of backups stored in S3 path

` Usage: mysql_backup.sh <Database_list>`
 Pass databases separated by single space

## Prerequisites

1. An IAM  user `backupuser_s3` with following policy is needed for this script. This user should be configured on the server where this script is executed.
s
```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::legalinc-db-backups"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::legalinc-db-backups/*"
            ]
        }
    ]
}
```

2. Create `.my.cnf` file in the home directory of the user which executes the script.

```
[client]
host = ordermanager-production.cgdgt1kn7bju.us-east-1.rds.amazonaws.com
user = RDS_USERNAME
password = RDS_PASSWORD
```